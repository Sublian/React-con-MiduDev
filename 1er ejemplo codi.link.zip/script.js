//vanilla javascript
//recuperar boton
const button = document.querySelector('button')

//al hacer click en el boton, debemos ejecutar una funcion
button.addEventListener('click', function() {
  
  //recuperar id del atributo Html
  const id =  button.getAttribute('data-id')
  //llamar servicio para actualziar si me gusta
  if(button.classList.contains('liked')){
    button.classList.remove('liked')
    button.innerText = 'Me Gusta'
  }else{
    button.classList.add('liked')
    button.innerText = 'Quitar Me Gusta'
  }
  })